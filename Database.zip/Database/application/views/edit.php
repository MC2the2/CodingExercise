<div class="container">
<div class="row">
<div class="col-md-12 mt-4">
<div class="card">
<div class="card-header">
<h5>
Editing Person
</h5>
</div>
<div class="card-body">
<form action="<?php echo base_url('person/update/'.$person->Id); ?>" method="POST">
<div class="form-group">
<label for="">First Name</label>
<input type="text" name="FirstName" value="<?= $person->FirstName ?>" class="form-control">
<small><?php echo form_error('FirstName'); ?></small>
</div>
<div class="form-group">
<label for="">Last Name</label>
<input type="text" name="LastName" value="<?= $person->LastName ?>"  class="form-control">
<small><?php echo form_error('LastName'); ?></small>
</div>
<div class="form-group">
<label for="">Email</label>
<input type="text" name="Email" value="<?= $person->Email ?>" class="form-control">
<small><?php echo form_error('Email'); ?></small>
</div>
<div class="form-group">
<label for="">Favorite Number</label>
<input type="text" name="FavoriteNumber" value="<?= $person->FavoriteNumber ?>" class="form-control"></div>
<small><?php echo form_error('FavoriteNumber'); ?></small>
<div class="form-group">
<button onclick="return confirmation('Are you sure you want to edit the person?  Press OK to continue and press cancel to stop the action.')" type="submit" class="btn btn-primary">Save</button>
<a href="<?php echo base_url('person'); ?>" class="btn btn-danger float-right">Back</a> 
</div>
</div>
</div>
</div>
</div>
</div>