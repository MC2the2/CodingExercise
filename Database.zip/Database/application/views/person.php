<div class="container">
<div class="row">
<div class="col-md-12 mt-4">
<div class="card">
<div class="card-header">
<h5>
<a href="<?php echo base_url('person/add'); ?>" class="btn btn-primary float-right" /> Add new person </a></h5>
</div>
<div class="card-body">
<table class = "table table-bordered display" id="myTable">
<thead>
<tr>
<th>ID</th>
<th>First Name</th>
<th>Last Name</th>
<th>Email</th>
<th>Fav Number</th>
<th>Edit</th>
<th>Delete</th>
</tr>
</thead>
<tbody>
<?php foreach ($person as $row) : ?>
<tr>
<td><?php echo $row->Id; ?></td>
<td><?php echo $row->FirstName; ?></td>
<td><?php echo $row->LastName; ?></td>
<td><?php echo $row->Email; ?></td>
<td><?php echo $row->FavoriteNumber; ?></td>
<td> <a href="<?php echo base_url('person/edit/'.$row->Id) ?>" class="btn btn-success btn-small">Edit</a></td>
<td> <a onclick="return confirmation('Are you sure you want to delete the person?  Press OK to continue and press cancel to stop the action.')" href="<?php echo base_url('person/delete/'.$row->Id) ?>" class="btn btn-danger btn-small">Delete</a></td>
</tr>


<?php endforeach; ?>
</tbody>
</table>

</div>
</div>
</div>
</div>
</div>