<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 


class Person_model extends CI_Model {


  function __construct() {
    parent::__construct();
  } 

function get_all_entries() {
  $query = $this->db->get('people');
  $results = array();
  foreach ($query->result() as $result) {
    $results[] = $result;
  }
  return $results;

}

	public function insertPerson($data)
	{
	$this->db->insert('people', $data);
	}

	public function editPerson($id)
	{
	$query = $this->db->get_where('people', ['Id' => $id]);
	return $query->row(); 
	}
	public function updatePerson($data, $id)
	{
	return $this->db->update('people', $data, ['Id' => $id]); 
	}

	public function deletePerson($id)
	{
	return $this->db->delete('people', ['Id' => $id]); 
	}
}