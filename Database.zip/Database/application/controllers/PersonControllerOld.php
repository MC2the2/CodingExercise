<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PersonController extends CI_Controller {



 public function __construct() {
    parent::__construct();
    
    // Load the todo model to make it available 
    // to *all* of the controller's actions 
    $this->load->model('Person_model');
  }
	public function index()
	{
 	$all_people = $this->Person_model->get_all_entries();

    // 2. Make the data available to the view
    		$data = array();
                $data['person'] = $all_people;
		$this->load->view('template/header');
		$this->load->view('person', $data);
		$this->load->view('template/footer');
	}
	public function add()
	{
		$this->load->view('template/header');
		$this->load->view('add');
		$this->load->view('template/footer');
	}

	public function store()
	{
	$this->form_validation->set_rules ('FirstName', 'First Name', 'required'); 
	$this->form_validation->set_rules ('LastName', 'Last Name', 'required'); 
	$this->form_validation->set_rules ('Email', 'Email', 'required'); 
	$this->form_validation->set_rules ('FavoriteNumber', 'Favorite Number', 'required'); 
	if($this->form_validation->run())
	{
		$data = [
		'FirstName' => $this->input->post('FirstName'), 
		'LastName' => $this->input->post('LastName'), 
		'Email' => $this->input->post('Email'), 
		'FavoriteNumber' => $this->input->post('FavoriteNumber')
		];
		$this->load->model('Person_model','per');
		$this->per->insertPerson($data);
		redirect(base_url('person'));
	}
	else
	{
		$this->add();
	}
	
	}

}
