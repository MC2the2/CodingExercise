<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PersonController extends CI_Controller {



	public function index()
	{
 	$all_people = $this->Person_model->get_all_entries();

    // 2. Make the data available to the view
    		$data = array();
                $data['person'] = $all_people;
		$this->load->view('template/header');
		$this->load->view('person', $data);
		$this->load->view('template/footer');
	}
	public function add($info = 0)
	{
		if(is_int($info)){
			$data['person'] = (object) array('FirstName' => '', 'LastName' => '', 'Email' => '', 'FavoriteNumber' => '');
                }
		else{
			$data['person']=(object) $info;
		}
		
		$this->load->view('template/header');
		$this->load->view('add', $data);
		$this->load->view('template/footer');

	
		
	}

	public function store()
	{
	$this->form_validation->set_rules ('FirstName', 'First Name', 'required'); 
	$this->form_validation->set_rules ('LastName', 'Last Name', 'required'); 
	$this->form_validation->set_rules ('Email', 'Email', 'required'); 
	$this->form_validation->set_rules ('FavoriteNumber', 'Favorite Number', 'required');

	$data = [
		'FirstName' => $this->input->post('FirstName'), 
		'LastName' => $this->input->post('LastName'), 
		'Email' => $this->input->post('Email'), 
		'FavoriteNumber' => $this->input->post('FavoriteNumber')
		]; 
	if($this->form_validation->run())
	{

		$this->load->model('Person_model','per');
		$this->per->insertPerson($data);
		redirect(base_url('person'));
	}
	else
	{
		
		(object) array('FirstName' => $this->input->post('FirstName'), 'LastName' => $this->input->post('LastName'), 'Email' => $this->input->post('Email'), 'FavoriteNumber' => $this->input->post('FavoriteNumber'));
		$this->add($data);
	}


	}
	public function edit($id, $info=0)
	{
		$this->load->model('Person_model','per');
		if(is_int($info)){
		$data['person'] = $this->per->editPerson($id);
		}
		else{
		$data['person'] = (object) $info;
		}

		$this->load->view('template/header');
		$this->load->view('edit', $data);
		$this->load->view('template/footer');
	
		
	}
	public function update($id){
	$this->form_validation->set_rules ('FirstName', 'First Name', 'required'); 
	$this->form_validation->set_rules ('LastName', 'Last Name', 'required'); 
	$this->form_validation->set_rules ('Email', 'Email', 'required'); 
	$this->form_validation->set_rules ('FavoriteNumber', 'Favorite Number', 'required'); 
 
	if($this->form_validation->run())
	{
		$data = [
		'FirstName' => $this->input->post('FirstName'), 
		'LastName' => $this->input->post('LastName'), 
		'Email' => $this->input->post('Email'), 
		'FavoriteNumber' => $this->input->post('FavoriteNumber'),
		];
		$this->load->model('Person_model','per');
		$this->per->updatePerson($data, $id);
		redirect(base_url('person'));
	}
	else{
	$data = [
		'FirstName' => $this->input->post('FirstName'), 
		'LastName' => $this->input->post('LastName'), 
		'Email' => $this->input->post('Email'), 
		'FavoriteNumber' => $this->input->post('FavoriteNumber'),
		'Id' => $id
		];
		$this->edit($id, $data);
	}
	}

	public function delete($id)
	{
		$this->load->model('Person_model','per');
		$this->per->deletePerson($id);
		redirect(base_url('person'));
	
		
	}



}
